# BDD Patient System - Selenium Java Framework

## Overview
This is a basic BDD framework built using Selenium WebDriver, Cucumber, and JUnit. It supports:
- Login functionality
- Adding and validating new patient records

## Project Structure
- `pages/` - Page Object Model classes
- `stepdefinitions/` - Step Definitions for Cucumber
- `features/` - Gherkin feature files
- `utils/` - Driver factory for managing WebDriver instances

## Prerequisites
- Java 11 or above
- Maven 3.x
- Chrome browser (latest)

## How to Run
1. Clone or extract the project
2. Navigate to the project directory
3. Run tests using Maven:
```bash
mvn test
```

## Feature Covered
- Login with valid credentials
- Add new patient with form validation