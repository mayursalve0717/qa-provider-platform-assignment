package stepdefinitions;

import io.cucumber.java.en.*;
import org.junit.Assert;
import pages.LoginPage;
import utils.DriverFactory;

public class LoginSteps {
    LoginPage loginPage = new LoginPage(DriverFactory.getDriver());

    @Given("user is on Login page")
    public void user_is_on_login_page() {
        DriverFactory.getDriver().get("https://qa-takehome.dtxplus.com/");
    }

    @When("user enters valid username and password")
    public void user_enters_credentials() {
        loginPage.enterUsername("admin");
        loginPage.enterPassword("password123");
    }

    @When("clicks on Login button")
    public void clicks_login() {
        loginPage.clickLogin();
    }

    @Then("user should be redirected to Patient Dashboard")
    public void redirected_to_dashboard() {
        Assert.assertTrue("Login failed!", loginPage.isLoginSuccessful());
    }
}