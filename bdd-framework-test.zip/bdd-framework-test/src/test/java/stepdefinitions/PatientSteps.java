package stepdefinitions;

import io.cucumber.java.en.*;
import org.junit.Assert;
import pages.DashboardPage;
import utils.DriverFactory;

public class PatientSteps {
    DashboardPage dashboardPage = new DashboardPage(DriverFactory.getDriver());

    @Then("patient table should be visible")
    public void verify_table_visible() {
        Assert.assertTrue("Patient table not visible", dashboardPage.isPatientTableVisible());
    }

    @When("user clicks Add Patient")
    public void user_clicks_add_patient() {
        dashboardPage.clickAddPatient();
    }

    @When("user enters patient details {string}, {string}, {string}")
    public void enter_patient_details(String mrn, String name, String dob) {
        dashboardPage.fillPatientForm(mrn, name, dob);
    }

    @And("submits the patient form")
    public void submits_patient_form() {
        dashboardPage.submitForm();
    }

    @Then("new patient with MRN {string} should be listed")
    public void verify_patient_added(String mrn) {
        Assert.assertTrue("Patient not added", dashboardPage.isPatientAdded(mrn));
    }
}