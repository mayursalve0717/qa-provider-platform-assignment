package utils;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DriverManager {

    public static void initialize() {
        WebDriverManager.chromedriver().setup(); // Auto-downloads and sets path
        WebDriver driver = new ChromeDriver();
        DriverFactory.setDriver(driver);
    }

    public static void quit() {
        WebDriver driver = DriverFactory.getDriver();
        if (driver != null) {
            driver.quit();
        }
    }
}