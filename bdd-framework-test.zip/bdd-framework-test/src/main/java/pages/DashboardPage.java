package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class DashboardPage {
    WebDriver driver;

    private By table = By.id("patientTable");
    private By addPatientBtn = By.xpath("//button[contains(text(), 'Add Patient')]");

    private By mrnField = By.name("mrn");
    private By nameField = By.name("name");
    private By dobField = By.name("dob");
    private By submitBtn = By.xpath("//button[contains(text(), 'Submit')]");

    public DashboardPage(WebDriver driver) {
        this.driver = driver;
    }

    public boolean isPatientTableVisible() {
        return driver.findElement(table).isDisplayed();
    }

    public void clickAddPatient() {
        driver.findElement(addPatientBtn).click();
    }

    public void fillPatientForm(String mrn, String name, String dob) {
        driver.findElement(mrnField).sendKeys(mrn);
        driver.findElement(nameField).sendKeys(name);
        driver.findElement(dobField).sendKeys(dob);
    }

    public void submitForm() {
        driver.findElement(submitBtn).click();
    }

    public boolean isPatientAdded(String mrn) {
        return driver.getPageSource().contains(mrn);
    }
}